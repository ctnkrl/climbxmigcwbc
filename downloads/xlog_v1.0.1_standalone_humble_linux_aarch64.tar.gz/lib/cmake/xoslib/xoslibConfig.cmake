
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was xoslibConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

# Mirror full xoslib: pull xlog when no COMPONENTS or when xlog is requested.
set(_xoslib_standalone_need_xlog OFF)
if(NOT xoslib_FIND_COMPONENTS)
  set(_xoslib_standalone_need_xlog ON)
elseif("xlog" IN_LIST xoslib_FIND_COMPONENTS)
  set(_xoslib_standalone_need_xlog ON)
endif()

if(_xoslib_standalone_need_xlog)
  if(NOT xlog_DIR)
    get_filename_component(_xoslib_standalone_cmake_parent "${CMAKE_CURRENT_LIST_DIR}/.." ABSOLUTE)
    if(EXISTS "${_xoslib_standalone_cmake_parent}/xlog/xlogConfig.cmake")
      set(xlog_DIR "${_xoslib_standalone_cmake_parent}/xlog")
    endif()
  endif()
  find_dependency(xlog)
endif()

# xos in-tree packages use xoslib::xlog; standalone install only exports xlog::*.
if(_xoslib_standalone_need_xlog AND NOT TARGET xoslib::xlog)
  add_library(xoslib::xlog INTERFACE IMPORTED)
  set_property(TARGET xoslib::xlog PROPERTY INTERFACE_LINK_LIBRARIES xlog::xlog)
endif()

if(TARGET xoslib::xlog)
  set(xoslib_xlog_FOUND TRUE)
endif()

check_required_components(xoslib)
