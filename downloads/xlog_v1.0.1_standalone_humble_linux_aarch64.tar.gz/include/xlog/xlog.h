#pragma once

#include <g3log/g3log.hpp>
#include <g3log/loglevels.hpp>

#include "xlog/log_controler.h"
#include "xlog/options.h"

namespace xos {
namespace log {

/// @brief 返回 libxlog 版本字符串 (如 "0.1.0")
const char *Version();

/// @brief 使用完整选项初始化
/// 文件Sink必须提供logger_id, 用于日志文件名称生成
void Initialize(const Options &options);

/// @brief 只启用终端 Sink
void Initialize(const ConsoleOptions &console_options);

/// @brief 只启用文件 Sink
void Initialize(const FileOptions &file_options);

/// @brief 运行时设置文件 Sink 日志级别
void SetFileLevel(LogLevel level);

/// @brief 运行时设置终端 Sink 日志级别
void SetConsoleLevel(LogLevel level);

/// @brief 运行时同时设置文件和终端 Sink 的日志级别
void SetLevel(LogLevel level);
}  // namespace log
}  // namespace xos
