#pragma once

#include <g3log/loglevels.hpp>
#include <g3log/logmessage.hpp>

#include "xlog/options.h"

namespace xos {
namespace log {

class ConsoleSink {
 public:
  explicit ConsoleSink(const ConsoleOptions& options);

  void ReceiveLogMessage(g3::LogMessageMover logEntry);

 private:
  enum FG_Color { YELLOW = 33, RED = 31, GREEN = 32, WHITE = 37 };

  FG_Color GetColor(const LEVELS& level) const;

  const ConsoleOptions& options_;
};

}  // namespace log
}  // namespace xos
