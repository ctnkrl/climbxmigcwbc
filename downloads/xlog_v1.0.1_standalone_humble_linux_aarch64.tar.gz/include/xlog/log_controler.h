#pragma once

#include <future>
#include <g3log/g3log.hpp>
#include <g3log/logworker.hpp>
#include <list>
#include <memory>
#include <mutex>

#include "xlog/options.h"

namespace xos {
namespace log {

class FileSink;

using SinkHandle = void*;

namespace detail {

struct SinkHandleBase {
  virtual ~SinkHandleBase() = default;
};

template <typename T>
struct TypedSinkHandle : SinkHandleBase {
  std::unique_ptr<g3::SinkHandle<T>> handle;
  explicit TypedSinkHandle(std::unique_ptr<g3::SinkHandle<T>> h)
      : handle(std::move(h)) {}
};

}  // namespace detail

/// Thread-safe singleton log controller. Initialize and GetInstance are safe
/// to call from multiple threads. Uses std::call_once for one-time init.
class LogControler {
 public:
  static LogControler& Initialize(const Options& options);
  static LogControler& GetInstance();

  ~LogControler();

  const Options& GetOptions() const;

  /// Set file sink min level at runtime. No-op if file sink is disabled.
  void SetFileLevel(LogLevel level);

  /// Set console sink min level at runtime. No-op if console sink is disabled.
  void SetConsoleLevel(LogLevel level);

  /// Set both file and console sink levels at runtime.
  void SetLevel(LogLevel level);

  /// Check if console sink would accept a message at given level.
  bool WouldAcceptConsole(LogLevel level) const;

  /// Check if file sink would accept a message at given level.
  bool WouldAcceptFile(LogLevel level) const;

  std::future<void> FlushFile();
  std::future<void> SyncFile();

  LogControler(const LogControler&) = delete;
  LogControler& operator=(const LogControler&) = delete;

 private:
  explicit LogControler(const Options& options);

  template <typename SinkType, typename Callable>
  SinkHandle AddSink(std::unique_ptr<SinkType> sink, Callable&& cb);

  void RemoveSink(SinkHandle handle);

  Options options_;
  std::unique_ptr<g3::LogWorker> worker_;
  std::list<std::unique_ptr<detail::SinkHandleBase>> sinks_;
  g3::SinkHandle<FileSink>* file_sink_handle_{nullptr};
  std::mutex mutex_;

  static std::unique_ptr<LogControler> instance_;
  static std::mutex instance_mutex_;
  static std::once_flag init_flag_;

  static void HandleSigwinch(int);
  static void OnProcessExit();
  static void StartSyncNotifyPipe();
  static void StopSyncNotifyPipe();
};

template <typename SinkType, typename Callable>
SinkHandle LogControler::AddSink(std::unique_ptr<SinkType> sink,
                                 Callable&& cb) {
  auto g3_handle =
      worker_->addSink(std::move(sink), std::forward<Callable>(cb));
  auto wrapper =
      std::make_unique<detail::TypedSinkHandle<SinkType>>(std::move(g3_handle));

  std::lock_guard<std::mutex> lock(mutex_);
  auto* ptr = wrapper.get();
  sinks_.push_back(std::move(wrapper));
  return static_cast<SinkHandle>(ptr);
}

}  // namespace log
}  // namespace xos
