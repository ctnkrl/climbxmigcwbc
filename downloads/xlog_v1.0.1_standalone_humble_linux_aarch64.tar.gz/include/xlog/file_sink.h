#pragma once

#include <atomic>
#include <chrono>
#include <cstddef>
#include <cstdio>
#include <filesystem>
#include <g3log/logmessage.hpp>
#include <memory>
#include <mutex>
#include <string>
#include <thread>

#include "xlog/options.h"

namespace xos {
namespace log {

class Rotator;

class FileSink {
 public:
  explicit FileSink(const FileOptions& options);
  ~FileSink();

  void ReceiveLogMessage(g3::LogMessageMover message);
  std::string FileName() const;

  void Flush();
  void Sync();

  FileSink(const FileSink&) = delete;
  FileSink& operator=(const FileSink&) = delete;

 private:
  void AddLogFileHeader();
  static std::string CreateLogFileName(const std::string& logger_id);
  bool RotateIfNeeded();
  bool OpenNewLogFile();
  void UpdateSymlink();
  void FlushPendingNoLock();
  void PeriodicFlushLoop();

  const FileOptions& options_;
  g3::LogMessage::LogDetailsFunc log_details_func_;
  std::string log_file_with_path_;
  FILE* fp_;
  std::string header_;
  bool first_entry_;
  std::size_t buffered_write_count_;
  std::chrono::steady_clock::time_point last_fflush_time_;
  std::size_t current_file_size_bytes_{0};
  std::filesystem::path file_dir_;
  std::unique_ptr<Rotator> rotator_;

  mutable std::mutex sink_mutex_;
  std::atomic<bool> stop_periodic_flush_{false};
  std::thread periodic_flush_thread_;
};

}  // namespace log
}  // namespace xos
