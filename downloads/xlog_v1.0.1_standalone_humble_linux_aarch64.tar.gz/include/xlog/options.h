#pragma once

#include <atomic>
#include <string>

#include "xlog/log_level.h"

namespace xos {
namespace log {

struct FileOptions {
  bool enable{true};
  std::string logger_id{""};
  std::string sub_dir{""};
  bool flush_on_write{false};
  bool sync_on_exit{true};
  bool write_header{true};
  bool write_tailer{true};
  std::atomic<LogLevel> level{LogLevel::INFO};

  FileOptions() = default;
  FileOptions(const FileOptions& o)
      : enable(o.enable),
        logger_id(o.logger_id),
        sub_dir(o.sub_dir),
        flush_on_write(o.flush_on_write),
        sync_on_exit(o.sync_on_exit),
        write_header(o.write_header),
        write_tailer(o.write_tailer) {
    level.store(o.level.load(std::memory_order_relaxed),
                std::memory_order_relaxed);
  }
  FileOptions& operator=(const FileOptions& o) {
    enable = o.enable;
    logger_id = o.logger_id;
    sub_dir = o.sub_dir;
    flush_on_write = o.flush_on_write;
    sync_on_exit = o.sync_on_exit;
    write_header = o.write_header;
    write_tailer = o.write_tailer;
    level.store(o.level.load(std::memory_order_relaxed),
                std::memory_order_relaxed);
    return *this;
  }
};

struct ConsoleOptions {
  bool enable{false};
  bool enable_color{true};
  std::atomic<LogLevel> level{LogLevel::INFO};

  ConsoleOptions() = default;
  ConsoleOptions(const ConsoleOptions& o)
      : enable(o.enable), enable_color(o.enable_color) {
    level.store(o.level.load(std::memory_order_relaxed),
                std::memory_order_relaxed);
  }
  ConsoleOptions& operator=(const ConsoleOptions& o) {
    enable = o.enable;
    enable_color = o.enable_color;
    level.store(o.level.load(std::memory_order_relaxed),
                std::memory_order_relaxed);
    return *this;
  }
};

struct Options {
  ConsoleOptions console;
  FileOptions file;
};

}  // namespace log
}  // namespace xos
