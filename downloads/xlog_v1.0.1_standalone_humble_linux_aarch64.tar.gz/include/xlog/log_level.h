#pragma once

#include <cctype>
#include <string>

namespace xos {
namespace log {

enum class LogLevel : int {
  DEBUG = 0,
  INFO = 1,
  WARNING = 2,
  FATAL = 3,
};

inline int LevelToInt(LogLevel level) {
  return static_cast<int>(level);
}

/// Parse log level from string: "debug"/"0", "info"/"1", "warning"/"warn"/"2",
/// "fatal"/"3". Case insensitive. Returns INFO for unknown values.
inline LogLevel LevelFromString(const std::string& s) {
  std::string lower = s;
  for (auto& c : lower) {
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
  }
  if (lower == "0" || lower == "debug") return LogLevel::DEBUG;
  if (lower == "1" || lower == "info") return LogLevel::INFO;
  if (lower == "2" || lower == "warn" || lower == "warning")
    return LogLevel::WARNING;
  if (lower == "3" || lower == "fatal") return LogLevel::FATAL;
  return LogLevel::INFO;
}

}  // namespace log
}  // namespace xos
