#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "xlog::xlog" for configuration "Release"
set_property(TARGET xlog::xlog APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(xlog::xlog PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libxlog.so"
  IMPORTED_SONAME_RELEASE "libxlog.so"
  )

list(APPEND _cmake_import_check_targets xlog::xlog )
list(APPEND _cmake_import_check_files_for_xlog::xlog "${_IMPORT_PREFIX}/lib/libxlog.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
