/**
 * @file xlog_python.cpp
 * @brief pybind11 Python bindings for libxlog
 */

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include <g3log/g3log.hpp>
#include <g3log/logcapture.hpp>
#include <g3log/loglevels.hpp>

#include "xlog/log_controler.h"
#include "xlog/options.h"
#include "xlog/xlog.h"

namespace py = pybind11;
namespace xlog = xos::log;

namespace {

// Filter at submission time to avoid race with async sink processing.
bool would_accept(xlog::LogLevel level) {
  auto& ctrl = xlog::LogControler::GetInstance();
  return ctrl.WouldAcceptConsole(level) || ctrl.WouldAcceptFile(level);
}

// Get caller's file, line, function from Python stack.
// When called from Python, sys._getframe(1) gives the caller's frame.
void get_python_caller_info(std::string& file, int& line, std::string& func) {
  try {
    py::object sys = py::module::import("sys");
    py::object getframe = sys.attr("_getframe");
    py::object frame = getframe(0);  // Caller's frame (Python that invoked us)
    file = frame.attr("f_code").attr("co_filename").cast<std::string>();
    line = frame.attr("f_lineno").cast<int>();
    func = frame.attr("f_code").attr("co_name").cast<std::string>();
    return;
  } catch (...) {
  }
  file = "<python>";
  line = 0;
  func = "?";
}

void log_impl(const std::string& msg, const LEVELS& level) {
  std::string file;
  int line = 0;
  std::string func;
  get_python_caller_info(file, line, func);
  LogCapture(file.c_str(), line, func.c_str(), level).stream() << msg;
}

void log_debug(const std::string& msg) {
  if (!would_accept(xlog::LogLevel::DEBUG)) return;
  log_impl(msg, G3LOG_DEBUG);
}

void log_info(const std::string& msg) {
  if (!would_accept(xlog::LogLevel::INFO)) return;
  log_impl(msg, INFO);
}

void log_warning(const std::string& msg) {
  if (!would_accept(xlog::LogLevel::WARNING)) return;
  log_impl(msg, WARNING);
}

void log_fatal(const std::string& msg) {
  if (!would_accept(xlog::LogLevel::FATAL)) return;
  log_impl(msg, FATAL);
}

}  // namespace

PYBIND11_MODULE(_native, m) {
  m.doc() = "libxlog Python bindings - Python interface for xos logging library";

  // Version
  m.def("version", &xlog::Version, "Return libxlog version string");

  // LogLevel enum
  py::enum_<xlog::LogLevel>(m, "LogLevel")
      .value("DEBUG", xlog::LogLevel::DEBUG)
      .value("INFO", xlog::LogLevel::INFO)
      .value("WARNING", xlog::LogLevel::WARNING)
      .value("FATAL", xlog::LogLevel::FATAL)
      .export_values();

  // FileOptions (level is atomic, use property for read/write)
  py::class_<xlog::FileOptions>(m, "FileOptions")
      .def(py::init<>())
      .def_readwrite("enable", &xlog::FileOptions::enable)
      .def_readwrite("logger_id", &xlog::FileOptions::logger_id)
      .def_readwrite("sub_dir", &xlog::FileOptions::sub_dir)
      .def_readwrite("flush_on_write", &xlog::FileOptions::flush_on_write)
      .def_readwrite("sync_on_exit", &xlog::FileOptions::sync_on_exit)
      .def_readwrite("write_header", &xlog::FileOptions::write_header)
      .def_readwrite("write_tailer", &xlog::FileOptions::write_tailer)
      .def_property(
          "level",
          [](const xlog::FileOptions& o) {
            return o.level.load(std::memory_order_relaxed);
          },
          [](xlog::FileOptions& o, xlog::LogLevel l) {
            o.level.store(l, std::memory_order_relaxed);
          });

  // ConsoleOptions
  py::class_<xlog::ConsoleOptions>(m, "ConsoleOptions")
      .def(py::init<>())
      .def_readwrite("enable", &xlog::ConsoleOptions::enable)
      .def_readwrite("enable_color", &xlog::ConsoleOptions::enable_color)
      .def_property(
          "level",
          [](const xlog::ConsoleOptions& o) {
            return o.level.load(std::memory_order_relaxed);
          },
          [](xlog::ConsoleOptions& o, xlog::LogLevel l) {
            o.level.store(l, std::memory_order_relaxed);
          });

  // Options
  py::class_<xlog::Options>(m, "Options")
      .def(py::init<>())
      .def_readwrite("console", &xlog::Options::console)
      .def_readwrite("file", &xlog::Options::file);

  // Initialize overloads
  m.def("initialize", py::overload_cast<const xlog::Options&>(&xlog::Initialize),
        py::arg("options"), "Initialize with full options (console + file)");

  m.def("initialize_console",
        py::overload_cast<const xlog::ConsoleOptions&>(&xlog::Initialize),
        py::arg("options"), "Initialize with console only");

  m.def("initialize_file",
        py::overload_cast<const xlog::FileOptions&>(&xlog::Initialize),
        py::arg("options"), "Initialize with file only");

  // Runtime level control
  m.def("set_file_level", &xlog::SetFileLevel, py::arg("level"),
        "Set file sink log level");
  m.def("set_console_level", &xlog::SetConsoleLevel, py::arg("level"),
        "Set console sink log level");
  m.def("set_level", &xlog::SetLevel, py::arg("level"),
        "Set both file and console log level");

  // Logging functions
  m.def("debug", &log_debug, py::arg("msg"), "Log debug message");
  m.def("info", &log_info, py::arg("msg"), "Log info message");
  m.def("warning", &log_warning, py::arg("msg"), "Log warning message");
  m.def("fatal", &log_fatal, py::arg("msg"), "Log fatal message");
}
