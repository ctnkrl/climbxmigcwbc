"""
xlog - libxlog Python 接口

提供 C++ libxlog 的 Python 绑定，以及 logging.Handler 桥接。

logging 用法：

    import logging
    import xlog
    from xlog import XlogHandler

    opts = xlog.Options()
    opts.file.enable = True
    opts.file.logger_id = "logger_id"
    opts.console.enable = True
    xlog.initialize(opts)

    logger = logging.getLogger("logger_id")
    logger.addHandler(XlogHandler())
    logger.setLevel(logging.DEBUG)
    logger.info("hello")
"""

import logging

from xlog._native import (
    ConsoleOptions,
    FileOptions,
    LogLevel,
    Options,
    debug,
    fatal,
    info,
    initialize,
    initialize_console,
    initialize_file,
    set_console_level,
    set_file_level,
    set_level,
    version,
    warning,
)

__all__ = [
    "ConsoleOptions",
    "FileOptions",
    "LogLevel",
    "Options",
    "XlogHandler",
    "debug",
    "fatal",
    "info",
    "initialize",
    "initialize_console",
    "initialize_file",
    "set_console_level",
    "set_file_level",
    "set_level",
    "version",
    "warning",
]


class XlogHandler(logging.Handler):
    """将 logging.LogRecord 转发到 xlog 的 Handler。

    级别映射：DEBUG->debug, INFO->info, WARNING/ERROR->warning, CRITICAL->fatal。
    """

    def __init__(self, level=logging.NOTSET):
        super().__init__(level)

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            level = record.levelno

            if level <= logging.DEBUG:
                debug(msg)
            elif level <= logging.INFO:
                info(msg)
            elif level < logging.CRITICAL:
                warning(msg)  # WARNING, ERROR -> warning
            else:
                fatal(msg)  # CRITICAL -> fatal
        except Exception:
            self.handleError(record)
