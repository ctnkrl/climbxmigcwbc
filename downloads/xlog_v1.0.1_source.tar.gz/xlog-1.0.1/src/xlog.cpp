#include "xlog/xlog.h"

#include <stdexcept>

namespace xos {
namespace log {

const char *Version() {
  return XLOG_VERSION;
}

void Initialize(const Options &options) {
  if (options.file.enable && options.file.logger_id.empty()) {
    throw std::logic_error{"logger id MUST supplied for file sink"};
  }
  LogControler::Initialize(options);
}

void Initialize(const ConsoleOptions &console_options) {
  Options options;
  options.console = console_options;
  options.file.enable = false;
  LogControler::Initialize(options);
}

void Initialize(const FileOptions &file_options) {
  if (file_options.enable && file_options.logger_id.empty()) {
    throw std::logic_error{"logger id MUST supplied for file sink"};
  }
  Options options;
  options.file = file_options;
  options.console.enable = false;
  LogControler::Initialize(options);
}

void SetFileLevel(LogLevel level) {
  LogControler::GetInstance().SetFileLevel(level);
}

void SetConsoleLevel(LogLevel level) {
  LogControler::GetInstance().SetConsoleLevel(level);
}

void SetLevel(LogLevel level) {
  LogControler::GetInstance().SetLevel(level);
}

}  // namespace log
}  // namespace xos
