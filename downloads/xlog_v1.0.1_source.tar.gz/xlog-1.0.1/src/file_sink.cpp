#include "xlog/file_sink.h"

#include <fcntl.h>
#include <pwd.h>
#include <sys/stat.h>
#include <unistd.h>

#include <cassert>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <g3log/loglevels.hpp>
#include <g3log/logmessage.hpp>
#include <g3log/time.hpp>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>

#include "log_format.h"
#include "log_level_filter.h"
#include "rotator.h"
#include "xlog_debug.h"

namespace {

namespace fs = std::filesystem;

const std::string kFileNameTimeFormatted = "%Y%m%d_%H%M%S";

bool StartsWithPath(const std::string& s, const char* prefix) {
  const size_t n = std::strlen(prefix);
  return s.size() >= n && s.compare(0, n, prefix) == 0;
}

const char* ResolveChownUserForLogDir(const std::string& log_dir) {
  if (StartsWithPath(log_dir, "/home/ubuntu")) {
    return "ubuntu";
  }
  if (StartsWithPath(log_dir, "/home/nvidia")) {
    return "nvidia";
  }
  const char* home = std::getenv("HOME");
  if (home && home[0] != '\0') {
    std::string home_dir(home);
    if (StartsWithPath(home_dir, "/home/ubuntu")) {
      return "ubuntu";
    }
    if (StartsWithPath(home_dir, "/home/nvidia")) {
      return "nvidia";
    }
  }
  return nullptr;
}

void TryChownPathToUser(const std::string& path, const char* user_name) {
  if (!user_name || path.empty()) {
    return;
  }
  if (geteuid() != 0) {
    return;
  }
  struct passwd* pw = getpwnam(user_name);
  if (!pw) {
    return;
  }
  const int chown_rc = chown(path.c_str(), pw->pw_uid, pw->pw_gid);
  (void)chown_rc;
}

void TryLchownPathToUser(const std::string& path, const char* user_name) {
  if (!user_name || path.empty()) {
    return;
  }
  if (geteuid() != 0) {
    return;
  }
  struct passwd* pw = getpwnam(user_name);
  if (!pw) {
    return;
  }
  const int chown_rc = lchown(path.c_str(), pw->pw_uid, pw->pw_gid);
  (void)chown_rc;
}

std::string ResolveLogDir() {
  if (fs::is_directory("/home/ubuntu")) {
    return "/home/ubuntu/logs/glogs";
  }
  if (fs::is_directory("/home/nvidia")) {
    return "/home/nvidia/logs/glogs";
  }
  const char* home = std::getenv("HOME");
  std::string home_dir = (home && home[0] != '\0') ? home : "/tmp";
  return home_dir + "/logs/glogs";
}

void EnsureDirExists(const std::string& path) {
  std::error_code ec;
  fs::create_directories(path, ec);
}

void SyncParentDirectoryOfFile(const std::string& file_path) {
  const fs::path parent = fs::path(file_path).parent_path();
  if (parent.empty()) {
    return;
  }
  const int dfd = open(parent.string().c_str(), O_RDONLY);
  if (dfd < 0) {
    return;
  }
  (void)fdatasync(dfd);
  (void)close(dfd);
}

std::string MakeHeader(const std::string& header_format) {
  auto now = std::chrono::system_clock::now();
  std::ostringstream oss;
  oss << "\t\tlog created at: "
      << g3::localtime_formatted(now, "%a %b %d %H:%M:%S %Y") << "\n";
  oss << header_format;
  return oss.str();
}

}  // namespace

namespace xos {
namespace log {

std::string FileSink::CreateLogFileName(const std::string& logger_id) {
  std::ostringstream oss;
  oss << logger_id << "_";
  auto now = std::chrono::system_clock::now();
  oss << g3::localtime_formatted(now, kFileNameTimeFormatted);
  oss << ".log";
  return oss.str();
}

FileSink::FileSink(const FileOptions& options)
    : options_(options),
      log_details_func_(&XlogLogDetailsToString),
      fp_(nullptr),
      header_(
          "\t\tLOG format: [YYYY-MM-DD HH:MM:SS.uuuuuu] [log_level] "
          "[filename:line_number] message"
          "\n\n\t\t(uuuuuu: 6-digit microseconds)\n\n"),
      first_entry_(true),
      buffered_write_count_(0),
      last_fflush_time_(std::chrono::steady_clock::now()) {
  if (options_.logger_id.empty()) {
    throw std::logic_error(
        "FileOptions.logger_id must not be empty for FileSink");
  }

  const std::string log_dir = ResolveLogDir();
  const char* const chown_user = ResolveChownUserForLogDir(log_dir);

  EnsureDirExists(log_dir);
  TryChownPathToUser(log_dir, chown_user);

  const std::string sub_dir =
      options_.sub_dir.empty() ? options_.logger_id : options_.sub_dir;
  const std::string actual_file_name = CreateLogFileName(options_.logger_id);
  const std::filesystem::path file_dir =
      std::filesystem::path(log_dir) / sub_dir;
  EnsureDirExists(file_dir.string());
  TryChownPathToUser(file_dir.string(), chown_user);
  file_dir_ = file_dir;
  rotator_ = std::make_unique<Rotator>(file_dir_, options_.logger_id);

  log_file_with_path_ = (file_dir_ / actual_file_name).string();
  fp_ = fopen(log_file_with_path_.c_str(), "w");

  if (!fp_) {
    std::cerr << "Cannot write log file to " << log_file_with_path_
              << ", attempting current directory" << std::endl;
  }
  assert(fp_ && "cannot open log file at startup");
  if (fp_) {
    TryChownPathToUser(log_file_with_path_, chown_user);
    current_file_size_bytes_ = 0;
    UpdateSymlink();
    if (!options_.flush_on_write) {
      periodic_flush_thread_ =
          std::thread([this] { PeriodicFlushLoop(); });
    }
  }
}

bool FileSink::OpenNewLogFile() {
  const std::string actual_file_name = CreateLogFileName(options_.logger_id);
  log_file_with_path_ = (file_dir_ / actual_file_name).string();
  fp_ = fopen(log_file_with_path_.c_str(), "w");
  if (!fp_) {
    return false;
  }

  const std::string log_dir = ResolveLogDir();
  const char* const chown_user = ResolveChownUserForLogDir(log_dir);
  TryChownPathToUser(log_file_with_path_, chown_user);

  current_file_size_bytes_ = 0;
  first_entry_ = true;
  buffered_write_count_ = 0;
  last_fflush_time_ = std::chrono::steady_clock::now();
  UpdateSymlink();
  return true;
}

bool FileSink::RotateIfNeeded() {
  if (!fp_ || !rotator_) {
    return false;
  }

  const std::size_t limit = rotator_->GetLimit();
  if (limit == 0 || current_file_size_bytes_ <= limit) {
    return false;
  }

  const std::string old_file = log_file_with_path_;
  fflush(fp_);
  (void)fdatasync(fileno(fp_));
  SyncParentDirectoryOfFile(old_file);
  fclose(fp_);
  fp_ = nullptr;

  if (!OpenNewLogFile()) {
    return false;
  }

  (void)rotator_->AddFile(old_file);
  return true;
}

FileSink::~FileSink() {
  stop_periodic_flush_.store(true, std::memory_order_release);
  if (periodic_flush_thread_.joinable()) {
    periodic_flush_thread_.join();
  }

  std::lock_guard<std::mutex> lock(sink_mutex_);
  if (fp_) {
    if (options_.write_tailer) {
      std::string exit_msg = "\n\t\tFileSink shutdown at: ";
      auto now = std::chrono::system_clock::now();
      exit_msg.append(
          g3::localtime_formatted(now, g3::internal::time_formatted));
      exit_msg += "\n";
      fwrite(exit_msg.data(), 1, exit_msg.size(), fp_);

      exit_msg.append("Log file at: [")
          .append(log_file_with_path_)
          .append("]\n");
#ifdef XLOG_DEBUG_ENABLE
      std::cerr << exit_msg << std::flush;
#endif
    }

    fflush(fp_);

    if (options_.sync_on_exit) {
      const int log_fd = fileno(fp_);
      fdatasync(log_fd);
      SyncParentDirectoryOfFile(log_file_with_path_);
    }

    fclose(fp_);
    fp_ = nullptr;
  }
}

void FileSink::Flush() {
  std::lock_guard<std::mutex> lock(sink_mutex_);
  if (fp_) {
    fflush(fp_);
    buffered_write_count_ = 0;
    last_fflush_time_ = std::chrono::steady_clock::now();
  }
}

void FileSink::Sync() {
  std::lock_guard<std::mutex> lock(sink_mutex_);
  if (fp_) {
    fflush(fp_);
    fdatasync(fileno(fp_));
    SyncParentDirectoryOfFile(log_file_with_path_);
    buffered_write_count_ = 0;
    last_fflush_time_ = std::chrono::steady_clock::now();
  }
}

void FileSink::FlushPendingNoLock() {
  if (!fp_ || options_.flush_on_write) {
    return;
  }
  if (buffered_write_count_ > 0) {
    fflush(fp_);
    buffered_write_count_ = 0;
    last_fflush_time_ = std::chrono::steady_clock::now();
  }
}

void FileSink::PeriodicFlushLoop() {
  constexpr std::chrono::seconds kInterval(10);
  constexpr std::chrono::milliseconds kStep(100);
  const int steps = static_cast<int>(
      std::chrono::duration_cast<std::chrono::milliseconds>(kInterval).count() /
      kStep.count());

  while (!stop_periodic_flush_.load(std::memory_order_acquire)) {
    for (int i = 0; i < steps; ++i) {
      if (stop_periodic_flush_.load(std::memory_order_acquire)) {
        return;
      }
      std::this_thread::sleep_for(kStep);
    }
    XLOG_DEBUG("FileSink", "Time limit reached, flush log\n");
    std::lock_guard<std::mutex> lock(sink_mutex_);
    FlushPendingNoLock();
  }
}

void FileSink::ReceiveLogMessage(g3::LogMessageMover message) {
  std::lock_guard<std::mutex> lock(sink_mutex_);
  if (!fp_) return;
  if (!detail::ShouldAcceptLog(message.get()._level,
                               options_.level.load(std::memory_order_relaxed))) {
    return;
  }

  if (first_entry_ && options_.write_header) {
    AddLogFileHeader();
    first_entry_ = false;
  }

  std::string data = message.get().toString(log_details_func_);
  fwrite(data.data(), 1, data.size(), fp_);
  current_file_size_bytes_ += data.size();
  (void)RotateIfNeeded();

  if (options_.flush_on_write) {
    fflush(fp_);
    last_fflush_time_ = std::chrono::steady_clock::now();
    return;
  }

  ++buffered_write_count_;
  const auto now = std::chrono::steady_clock::now();
  constexpr std::chrono::seconds kMaxBufferedDuration(10);
  if (buffered_write_count_ >= 100 ||
      (now - last_fflush_time_) >= kMaxBufferedDuration) {
    fflush(fp_);
    buffered_write_count_ = 0;
    last_fflush_time_ = now;
  }
}

std::string FileSink::FileName() const {
  std::lock_guard<std::mutex> lock(sink_mutex_);
  return log_file_with_path_;
}

void FileSink::AddLogFileHeader() {
  std::string hdr = MakeHeader(header_);
  fwrite(hdr.data(), 1, hdr.size(), fp_);
  current_file_size_bytes_ += hdr.size();
}

void FileSink::UpdateSymlink() {
  const fs::path symlink_path = file_dir_ / (options_.logger_id + ".log");
  std::error_code ec;
  fs::remove(symlink_path, ec);
  fs::create_symlink(fs::path(log_file_with_path_).filename(), symlink_path,
                     ec);
  const std::string log_dir = ResolveLogDir();
  const char* const chown_user = ResolveChownUserForLogDir(log_dir);
  TryLchownPathToUser(symlink_path.string(), chown_user);
}

}  // namespace log
}  // namespace xos
