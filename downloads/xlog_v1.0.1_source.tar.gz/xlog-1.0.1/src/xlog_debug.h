#pragma once

#ifdef XLOG_DEBUG_ENABLE
#include <cstdio>

#define XLOG_DEBUG(component, fmt, ...)                                        \
  do {                                                                         \
    std::fprintf(stderr, "[xlog][%s] " fmt, (component), ##__VA_ARGS__);       \
  } while (false)
#else
#define XLOG_DEBUG(...) ((void)0)
#endif
