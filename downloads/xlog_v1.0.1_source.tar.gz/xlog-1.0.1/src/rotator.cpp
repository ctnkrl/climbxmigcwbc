#include "rotator.h"

#include <fcntl.h>
#include <unistd.h>

#include <algorithm>
#include <cctype>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <exception>
#include <fstream>
#include <system_error>
#include <vector>

#include "json.hpp"
#include "xlog_debug.h"

namespace xos {
namespace log {

namespace fs = std::filesystem;

namespace {

bool StartsWith(const std::string& s, const std::string& prefix) {
  return s.size() >= prefix.size() && s.compare(0, prefix.size(), prefix) == 0;
}

void SyncDirectory(const fs::path& dir) {
  const int dfd = open(dir.string().c_str(), O_RDONLY);
  if (dfd < 0) {
    return;
  }
  (void)fdatasync(dfd);
  (void)close(dfd);
}

std::chrono::seconds ParseDuration(const std::string& s) {
  if (s.empty()) return std::chrono::seconds{0};

  std::size_t pos = 0;
  long long value = 0;
  while (pos < s.size() && std::isdigit(static_cast<unsigned char>(s[pos]))) {
    value = value * 10 + (s[pos] - '0');
    ++pos;
  }

  if (pos >= s.size()) return std::chrono::seconds{value};

  switch (s[pos]) {
    case 'd':
      return std::chrono::seconds{value * 24 * 3600};
    case 'h':
      return std::chrono::seconds{value * 3600};
    case 'm':
      return std::chrono::seconds{value * 60};
    default:
      return std::chrono::seconds{value};
  }
}

}  // namespace

Rotator::Rotator(fs::path log_dir, std::string logger_id)
    : log_dir_(std::move(log_dir)), logger_id_(std::move(logger_id)) {
  XLOG_DEBUG("rotator", "construct log_dir=%s logger_id=%s\n",
               log_dir_.string().c_str(), logger_id_.c_str());

  LoadConfigFromEnv();

  std::error_code ec;
  if (fs::is_directory(log_dir_, ec)) {
    for (const auto& entry : fs::directory_iterator(log_dir_, ec)) {
      if (ec) break;
      if (!entry.is_regular_file(ec) || ec) continue;
      const std::string name = entry.path().filename().string();
      if (StartsWith(name, logger_id_ + "_") &&
          entry.path().extension() == ".log") {
        files_.push_back(entry.path());
        std::error_code sz_ec;
        const auto sz = fs::file_size(entry.path(), sz_ec);
        if (!sz_ec) {
          total_size_ += sz;
        }
      }
    }
  }

  std::sort(files_.begin(), files_.end(),
            [](const fs::path& a, const fs::path& b) {
              std::error_code ec_a;
              std::error_code ec_b;
              const auto ta = fs::last_write_time(a, ec_a);
              const auto tb = fs::last_write_time(b, ec_b);
              if (ec_a || ec_b) {
                return a.string() > b.string();
              }
              return ta > tb;
            });

  XLOG_DEBUG("rotator",
               "scanned matching .log files count=%zu mode=%d size_limit=%zu "
               "total_limit=%zu total_size=%zu\n",
               files_.size(), static_cast<int>(mode_), size_policy_.size_limit,
               size_policy_.total_limit, total_size_);

  CleanupIfNeeded();
}

void Rotator::LoadConfigFromEnv() {
  const char* cfg = std::getenv("XLOG_CONFIG_FILE");
  if (!cfg || cfg[0] == '\0') {
    XLOG_DEBUG("rotator",
                 "LoadConfigFromEnv: XLOG_CONFIG_FILE unset, use defaults\n");
    return;
  }

  std::error_code ec;
  const fs::path cfg_path(cfg);
  if (!fs::is_regular_file(cfg_path, ec) || ec) {
    XLOG_DEBUG("rotator",
                 "LoadConfigFromEnv: config not a regular file: %s\n",
                 cfg_path.string().c_str());
    return;
  } else {
    XLOG_DEBUG("rotator", "Using config file: %s\n",
                 cfg_path.string().c_str());
  }

  try {
    std::ifstream ifs(cfg_path);
    if (!ifs.good()) {
      return;
    }

    const nlohmann::json j =
        nlohmann::json::parse(ifs, nullptr, true, true);

    nlohmann::json rotation;
    if (j.contains("log_rotation")) {
      rotation = j["log_rotation"];
    } else {
      XLOG_DEBUG("rotator",
                   "LoadConfigFromEnv: no log_rotation in %s\n",
                   cfg_path.string().c_str());
      return;
    }

    XLOG_DEBUG("rotator", "LoadConfigFromEnv: loaded %s\n",
                 cfg_path.string().c_str());

    auto apply_cfg = [this](const nlohmann::json& cfg_obj) {
      if (!cfg_obj.is_object()) return;

      if (cfg_obj.contains("mode")) {
        const std::string mode = cfg_obj["mode"].get<std::string>();
        if (mode == "size") {
          mode_ = RotationMode::Size;
        } else if (mode == "time") {
          mode_ = RotationMode::Time;
        } else if (mode == "mixed") {
          mode_ = RotationMode::Mixed;
        }
      }

      if (cfg_obj.contains("max_file_size")) {
        const auto limit = cfg_obj["max_file_size"].get<long long>();
        if (limit > 0) {
          size_policy_.size_limit = static_cast<std::size_t>(limit);
        }
      }

      if (cfg_obj.contains("size_policy") &&
          cfg_obj["size_policy"].is_object()) {
        const auto& sp = cfg_obj["size_policy"];
        if (sp.contains("total_limit")) {
          const auto total = sp["total_limit"].get<long long>();
          if (total > 0) {
            size_policy_.total_limit = static_cast<std::size_t>(total);
          }
        }
      }

      if (cfg_obj.contains("time_policy") &&
          cfg_obj["time_policy"].is_object()) {
        const auto& tp = cfg_obj["time_policy"];
        if (tp.contains("druation")) {
          time_policy_.duration =
              ParseDuration(tp["druation"].get<std::string>());
        }
      }
    };

    if (rotation.contains("default")) {
      apply_cfg(rotation["default"]);
    }
    if (rotation.contains(logger_id_)) {
      apply_cfg(rotation[logger_id_]);
    }

    XLOG_DEBUG("rotator",
                 "LoadConfigFromEnv: effective mode=%d size_limit=%zu "
                 "total_limit=%zu duration_s=%lld\n",
                 static_cast<int>(mode_), size_policy_.size_limit,
                 size_policy_.total_limit,
                 static_cast<long long>(time_policy_.duration.count()));
  } catch (std::exception& e) {
    XLOG_DEBUG("rotator",
                 "LoadConfigFromEnv: parse failed, using defaults (exception)\n");
    XLOG_DEBUG("rotator", "%s\n", e.what());
    return;
  }
}

std::size_t Rotator::GetLimit() const {
  return size_policy_.size_limit;
}

bool Rotator::AddFile(const fs::path& latest_file) {
  if (!latest_file.empty()) {
    XLOG_DEBUG("rotator", "AddFile: %s\n", latest_file.string().c_str());
    files_.insert(files_.begin(), latest_file);
    std::error_code ec;
    const auto sz = fs::file_size(latest_file, ec);
    if (!ec) {
      total_size_ += sz;
    }
  }
  CleanupIfNeeded();
  return true;
}

void Rotator::CleanupIfNeeded() {
  switch (mode_) {
    case RotationMode::Size:
      CleanupByTotalSize();
      break;
    case RotationMode::Time:
      CleanupByTime();
      break;
    case RotationMode::Mixed:
      CleanupByTime();
      CleanupByTotalSize();
      break;
  }
}

void Rotator::CleanupByTotalSize() {
  if (size_policy_.total_limit == 0) return;

  bool removed_any = false;
  while (total_size_ > size_policy_.total_limit && !files_.empty()) {
    const fs::path victim = files_.back();
    std::error_code ec;
    const auto sz = fs::file_size(victim, ec);
    files_.pop_back();
    fs::remove(victim, ec);
    XLOG_DEBUG("rotator",
                 "CleanupByTotalSize: remove %s ec=%d %s\n",
                 victim.string().c_str(), ec.value(), ec.message().c_str());
    if (!ec && sz != static_cast<std::uintmax_t>(-1)) {
      total_size_ -= sz;
    }
    removed_any = removed_any || (!ec);
  }
  if (removed_any) {
    SyncDirectory(log_dir_);
  }
}

void Rotator::CleanupByTime() {
  if (time_policy_.duration.count() <= 0) return;

  const auto now = fs::file_time_type::clock::now();
  const auto cutoff = now - time_policy_.duration;

  bool removed_any = false;
  auto it = files_.begin();
  while (it != files_.end()) {
    std::error_code ec;
    const auto mtime = fs::last_write_time(*it, ec);
    if (!ec && mtime < cutoff) {
      const fs::path victim = *it;
      std::error_code sz_ec;
      const auto sz = fs::file_size(victim, sz_ec);
      fs::remove(victim, ec);
      XLOG_DEBUG("rotator",
                   "CleanupByTime: remove %s ec=%d %s\n",
                   victim.string().c_str(), ec.value(), ec.message().c_str());
      if (!ec && !sz_ec && sz != static_cast<std::uintmax_t>(-1)) {
        total_size_ -= sz;
      }
      removed_any = removed_any || (!ec);
      it = files_.erase(it);
    } else {
      ++it;
    }
  }
  if (removed_any) {
    SyncDirectory(log_dir_);
  }
}

}  // namespace log
}  // namespace xos
