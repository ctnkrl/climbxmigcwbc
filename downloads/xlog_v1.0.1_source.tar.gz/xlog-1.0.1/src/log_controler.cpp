#include "xlog/log_controler.h"

#include <poll.h>
#include <sys/eventfd.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <csignal>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <thread>

#ifdef XLOG_HAS_ROS2
#include <rclcpp/utilities.hpp>
#endif

#include "xlog/console_sink.h"
#include "xlog/file_sink.h"
#include "xlog/log_level.h"

namespace xos {
namespace log {

std::unique_ptr<LogControler> LogControler::instance_;
std::mutex LogControler::instance_mutex_;
std::once_flag LogControler::init_flag_;

LogControler& LogControler::Initialize(const Options& options) {
  std::call_once(init_flag_,
                 [&options]() { instance_.reset(new LogControler(options)); });
  std::lock_guard<std::mutex> lock(instance_mutex_);
  if (!instance_) {
    throw std::logic_error("LogControler initialization failed");
  }
  return *instance_;
}

LogControler& LogControler::GetInstance() {
  std::lock_guard<std::mutex> lock(instance_mutex_);
  if (!instance_) {
    throw std::logic_error(
        "LogControler not initialized, call Initialize() first");
  }
  return *instance_;
}

LogControler::LogControler(const Options& options)
    : options_(options), worker_(g3::LogWorker::createLogWorker()) {
  if (options_.file.enable) {
    auto file_sink = std::make_unique<FileSink>(options_.file);
    auto g3_handle =
        worker_->addSink(std::move(file_sink), &FileSink::ReceiveLogMessage);
    file_sink_handle_ = g3_handle.get();
    auto wrapper = std::make_unique<detail::TypedSinkHandle<FileSink>>(
        std::move(g3_handle));
    std::lock_guard<std::mutex> lock(mutex_);
    sinks_.push_back(std::move(wrapper));
  }

  if (options_.console.enable) {
    auto console_sink = std::make_unique<ConsoleSink>(options_.console);
    AddSink(std::move(console_sink), &ConsoleSink::ReceiveLogMessage);
  }

  g3::initializeLogging(worker_.get());

  if (options_.file.enable) {
    StartSyncNotifyPipe();
  }

  struct sigaction sa;
  std::memset(&sa, 0, sizeof(sa));
  sa.sa_handler = &LogControler::HandleSigwinch;
  sigemptyset(&sa.sa_mask);
  sa.sa_flags = 0;
  sigaction(SIGWINCH, &sa, nullptr);

  if (options_.file.enable) {
    std::atexit(LogControler::OnProcessExit);
  }

  try {
#ifdef XLOG_HAS_ROS2
    rclcpp::on_shutdown([]() {
      try {
        auto t0 = std::chrono::steady_clock::now();
        auto& instance = LogControler::GetInstance();
        instance.SyncFile().wait();
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now() - t0);
        LOG(INFO) << "Sync to disk on ROS shutdown (async), used "
                  << elapsed.count() << " ms";
      } catch (...) {
      }
    });
#else
    // ROS2 disabled: no-op
#endif
  } catch (...) {
  }
}

LogControler::~LogControler() {
  auto t0 = std::chrono::steady_clock::now();
  if (options_.file.enable) {
    StopSyncNotifyPipe();
  }
  auto elapsed_before_reset =
      std::chrono::duration_cast<std::chrono::milliseconds>(
          std::chrono::steady_clock::now() - t0);
#ifdef XLOG_DEBUG_ENABLE
  std::cerr << "xlog: ~LogControler() StopSyncNotifyPipe done, used "
            << elapsed_before_reset.count() << " ms";
#else
  LOG(INFO) << "xlog: ~LogControler() StopSyncNotifyPipe done, used "
            << elapsed_before_reset.count() << " ms";
#endif
  worker_.reset();
}

const Options& LogControler::GetOptions() const {
  return options_;
}

namespace {
int ClampLevel(int level) {
  if (level < 0) return 0;
  if (level > 3) return 3;
  return level;
}
}  // namespace

void LogControler::SetFileLevel(LogLevel level) {
  if (options_.file.enable) {
    options_.file.level.store(static_cast<LogLevel>(ClampLevel(LevelToInt(level))),
                              std::memory_order_relaxed);
  }
}

void LogControler::SetConsoleLevel(LogLevel level) {
  if (options_.console.enable) {
    options_.console.level.store(
        static_cast<LogLevel>(ClampLevel(LevelToInt(level))),
        std::memory_order_relaxed);
  }
}

void LogControler::SetLevel(LogLevel level) {
  LogLevel clamped = static_cast<LogLevel>(ClampLevel(LevelToInt(level)));
  if (options_.file.enable) {
    options_.file.level.store(clamped, std::memory_order_relaxed);
  }
  if (options_.console.enable) {
    options_.console.level.store(clamped, std::memory_order_relaxed);
  }
}

bool LogControler::WouldAcceptConsole(LogLevel level) const {
  if (!options_.console.enable) return false;
  return LevelToInt(level) >=
         LevelToInt(options_.console.level.load(std::memory_order_relaxed));
}

bool LogControler::WouldAcceptFile(LogLevel level) const {
  if (!options_.file.enable) return false;
  return LevelToInt(level) >=
         LevelToInt(options_.file.level.load(std::memory_order_relaxed));
}

std::future<void> LogControler::FlushFile() {
  if (file_sink_handle_) {
    return file_sink_handle_->call(&FileSink::Flush);
  }
  std::promise<void> p;
  p.set_value();
  return p.get_future();
}

std::future<void> LogControler::SyncFile() {
  if (file_sink_handle_) {
    return file_sink_handle_->call(&FileSink::Sync);
  }
  std::promise<void> p;
  p.set_value();
  return p.get_future();
}

namespace {

int g_sync_eventfd = -1;
int g_shutdown_eventfd = -1;
std::thread g_sync_thread;

void SyncNotifyThreadFunc(int sync_fd, int shutdown_fd) {
  struct pollfd fd[2] = {
      {sync_fd, POLLIN, 0},
      {shutdown_fd, POLLIN, 0},
  };
  while (poll(fd, 2, -1) > 0) {
    if (fd[1].revents & POLLIN) {
      uint64_t val;
      [[maybe_unused]] ssize_t n = read(shutdown_fd, &val, sizeof(val));
      (void)n;
      break;
    }
    if (fd[0].revents & POLLIN) {
      uint64_t val;
      if (read(sync_fd, &val, sizeof(val)) > 0) {
        try {
          auto t0 = std::chrono::steady_clock::now();
          auto& instance = LogControler::GetInstance();
          LOG(INFO) << "Syncing to disk on SIGWINCH";
          instance.SyncFile().wait();
          auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
              std::chrono::steady_clock::now() - t0);
          LOG(INFO) << "Syncd to disk on SIGWINCH, used " << elapsed.count()
                    << "ms";
        } catch (...) {
        }
      }
    }
  }
  close(sync_fd);
  close(shutdown_fd);
}

}  // namespace

void LogControler::StartSyncNotifyPipe() {
  int sync_fd = eventfd(0, EFD_CLOEXEC);
  int shutdown_fd = eventfd(0, EFD_CLOEXEC);
  if (sync_fd < 0 || shutdown_fd < 0) {
    if (sync_fd >= 0) close(sync_fd);
    if (shutdown_fd >= 0) close(shutdown_fd);
    return;
  }
  g_sync_eventfd = sync_fd;
  g_shutdown_eventfd = shutdown_fd;
  g_sync_thread = std::thread(SyncNotifyThreadFunc, sync_fd, shutdown_fd);
}

void LogControler::StopSyncNotifyPipe() {
  int shutdown_fd = g_shutdown_eventfd;
  g_sync_eventfd = g_shutdown_eventfd = -1;
  if (shutdown_fd >= 0) {
    const uint64_t one = 1;
    [[maybe_unused]] ssize_t n = write(shutdown_fd, &one, sizeof(one));
    (void)n;
  }
  if (g_sync_thread.joinable()) {
    g_sync_thread.join();
  }
}

void LogControler::HandleSigwinch(int) {
  if (g_sync_eventfd >= 0) {
    const uint64_t one = 1;
    [[maybe_unused]] ssize_t n = write(g_sync_eventfd, &one, sizeof(one));
    (void)n;
  }
}

void LogControler::RemoveSink(SinkHandle handle) {
  std::lock_guard<std::mutex> lock(mutex_);
  auto it = std::find_if(sinks_.begin(), sinks_.end(), [handle](const auto& s) {
    return static_cast<SinkHandle>(s.get()) == handle;
  });
  if (it != sinks_.end()) {
    sinks_.erase(it);
  }
}

void LogControler::OnProcessExit() {
  try {
    if (instance_) {
      instance_->SyncFile().wait();
#ifdef XLOG_DEBUG_ENABLE
      std::cerr << "xlog: Data synced to disk on normal exit\n" << std::flush;
#else
      LOG(INFO) << "xlog: Data synced to disk on normal exit\n";
#endif
    }
    StopSyncNotifyPipe();
    instance_.reset();
  } catch (...) {
  }
}

}  // namespace log
}  // namespace xos
