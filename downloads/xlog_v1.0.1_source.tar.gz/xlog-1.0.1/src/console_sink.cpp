#include "xlog/console_sink.h"

#include <iostream>
#include <sstream>

#include "log_format.h"
#include "log_level_filter.h"

namespace xos {
namespace log {

ConsoleSink::ConsoleSink(const ConsoleOptions& options) : options_(options) {}

void ConsoleSink::ReceiveLogMessage(g3::LogMessageMover logEntry) {
  if (!detail::ShouldAcceptLog(logEntry.get()._level,
                               options_.level.load(std::memory_order_relaxed))) {
    return;
  }

  const auto level = logEntry.get()._level;
  std::ostringstream oss;

  if (options_.enable_color) {
    const auto color = GetColor(level);
    oss << "\033[" << color << "m"
        << logEntry.get().toString(&XlogLogDetailsToString) << "\033[m"
        << std::endl;
  } else {
    oss << logEntry.get().toString(&XlogLogDetailsToString) << std::endl;
  }

  std::cout << oss.str();
}

ConsoleSink::FG_Color ConsoleSink::GetColor(const LEVELS& level) const {
  if (level.value == WARNING.value) {
    return YELLOW;
  }
  if (level.value == G3LOG_DEBUG.value) {
    return GREEN;
  }
  if (g3::internal::wasFatal(level)) {
    return RED;
  }
  return WHITE;
}

}  // namespace log
}  // namespace xos
