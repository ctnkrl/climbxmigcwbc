#pragma once

#include <g3log/logmessage.hpp>
#include <sstream>
#include <string>

namespace xos {
namespace log {

/// Format: [YYYY-MM-DD HH:MM:SS.uuuuuu] [log_level] [filename:line_number]
inline std::string XlogLogDetailsToString(const g3::LogMessage& msg) {
  std::ostringstream oss;
  oss << '[' << msg.timestamp("%Y-%m-%d %H:%M:%S.%f6") << "] " << '['
      << msg.level() << "] " << '[' << msg.file() << ':' << msg.line() << "] ";
  return oss.str();
}

}  // namespace log
}  // namespace xos
