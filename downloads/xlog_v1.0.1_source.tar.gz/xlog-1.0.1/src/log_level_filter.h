#pragma once

/// Internal helpers for g3log message filtering (not part of the installed API).

#include <g3log/loglevels.hpp>

#include "xlog/log_level.h"

namespace xos {
namespace log {
namespace detail {

inline LogLevel ToLogLevel(const LEVELS& lvl) {
  if (g3::internal::wasFatal(lvl)) {
    return LogLevel::FATAL;
  }
  if (lvl.value == G3LOG_DEBUG.value) {
    return LogLevel::DEBUG;
  }
  if (lvl.value == INFO.value) {
    return LogLevel::INFO;
  }
  if (lvl.value == WARNING.value) {
    return LogLevel::WARNING;
  }
  return LogLevel::INFO;
}

/// Returns true if message should be logged (msg_level >= min_level).
inline bool ShouldAcceptLog(const LEVELS& msg_level, LogLevel min_level) {
  int mi = LevelToInt(min_level);
  if (mi < 0) mi = 0;
  if (mi > 3) mi = 3;
  return LevelToInt(ToLogLevel(msg_level)) >= mi;
}

}  // namespace detail
}  // namespace log
}  // namespace xos
