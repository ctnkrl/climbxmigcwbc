#pragma once

#include <chrono>
#include <cstddef>
#include <filesystem>
#include <string>
#include <vector>

namespace xos {
namespace log {

enum class RotationMode {
  Size,
  Time,
  Mixed,
};

struct SizePolicy {
  std::size_t size_limit{10 * 1024 * 1024};
  std::size_t total_limit{10 * 1024 * 1024 * 10};
};

struct TimePolicy {
  std::chrono::seconds duration{3 * 24 * 3600};
};

class Rotator {
 public:
  explicit Rotator(std::filesystem::path log_dir, std::string logger_id);
  ~Rotator() = default;

  bool AddFile(const std::filesystem::path& latest_file);
  std::size_t GetLimit() const;

 private:
  void LoadConfigFromEnv();
  void CleanupIfNeeded();
  void CleanupByTotalSize();
  void CleanupByTime();

  std::filesystem::path log_dir_;
  std::string logger_id_;

  RotationMode mode_{RotationMode::Size};
  SizePolicy size_policy_;
  TimePolicy time_policy_;

  std::size_t total_size_{0};
  std::vector<std::filesystem::path> files_;
};

}  // namespace log
}  // namespace xos
