// Unit tests for libxlog

#include <gtest/gtest.h>

#include <atomic>
#include <cstring>
#include <stdexcept>

#ifdef XLOG_HAS_ROS2
#include <rclcpp/rclcpp.hpp>
#endif

#include "xlog/file_sink.h"
#include "xlog/log_controler.h"
#include "xlog/log_level.h"
#include "xlog/options.h"
#include "xlog/xlog.h"

namespace xos {
namespace log {

// =============================================================================
// LogLevel, LevelToInt, LevelFromString (no initialization required)
// =============================================================================

TEST(LogLevelTest, LevelToInt) {
  EXPECT_EQ(0, LevelToInt(LogLevel::DEBUG));
  EXPECT_EQ(1, LevelToInt(LogLevel::INFO));
  EXPECT_EQ(2, LevelToInt(LogLevel::WARNING));
  EXPECT_EQ(3, LevelToInt(LogLevel::FATAL));
}

TEST(LogLevelTest, LevelFromStringNumeric) {
  EXPECT_EQ(LogLevel::DEBUG, LevelFromString("0"));
  EXPECT_EQ(LogLevel::INFO, LevelFromString("1"));
  EXPECT_EQ(LogLevel::WARNING, LevelFromString("2"));
  EXPECT_EQ(LogLevel::FATAL, LevelFromString("3"));
}

TEST(LogLevelTest, LevelFromStringNames) {
  EXPECT_EQ(LogLevel::DEBUG, LevelFromString("debug"));
  EXPECT_EQ(LogLevel::DEBUG, LevelFromString("DEBUG"));
  EXPECT_EQ(LogLevel::INFO, LevelFromString("info"));
  EXPECT_EQ(LogLevel::INFO, LevelFromString("INFO"));
  EXPECT_EQ(LogLevel::WARNING, LevelFromString("warning"));
  EXPECT_EQ(LogLevel::WARNING, LevelFromString("warn"));
  EXPECT_EQ(LogLevel::WARNING, LevelFromString("WARNING"));
  EXPECT_EQ(LogLevel::FATAL, LevelFromString("fatal"));
  EXPECT_EQ(LogLevel::FATAL, LevelFromString("FATAL"));
}

TEST(LogLevelTest, LevelFromStringUnknownReturnsInfo) {
  EXPECT_EQ(LogLevel::INFO, LevelFromString(""));
  EXPECT_EQ(LogLevel::INFO, LevelFromString("invalid"));
  EXPECT_EQ(LogLevel::INFO, LevelFromString("trace"));
}

TEST(FileSinkTest, ThrowsWhenLoggerIdEmpty) {
  FileOptions opts;
  opts.logger_id = "";
  EXPECT_THROW(FileSink sink(opts), std::logic_error);
}

// =============================================================================
// Options defaults
// =============================================================================

TEST(OptionsTest, FileOptionsDefaults) {
  FileOptions opts;
  EXPECT_TRUE(opts.enable);
  EXPECT_EQ("", opts.logger_id);
  EXPECT_EQ("", opts.sub_dir);
  EXPECT_FALSE(opts.flush_on_write);
  EXPECT_TRUE(opts.sync_on_exit);
  EXPECT_TRUE(opts.write_header);
  EXPECT_TRUE(opts.write_tailer);
  EXPECT_EQ(LogLevel::INFO, opts.level.load(std::memory_order_relaxed));
}

TEST(OptionsTest, ConsoleOptionsDefaults) {
  ConsoleOptions opts;
  EXPECT_FALSE(opts.enable);
  EXPECT_TRUE(opts.enable_color);
  EXPECT_EQ(LogLevel::INFO, opts.level.load(std::memory_order_relaxed));
}

// =============================================================================
// Version
// =============================================================================

TEST(VersionTest, ReturnsNonEmpty) {
  const char* v = Version();
  ASSERT_NE(nullptr, v);
  EXPECT_GT(std::strlen(v), 0u);
}

// =============================================================================
// Integration: Initialize + SetLevel + WouldAccept
// =============================================================================

class XlogIntegrationTest : public ::testing::Test {
 protected:
  static void SetUpTestSuite() {
#ifdef XLOG_HAS_ROS2
    if (!rclcpp::ok()) {
      rclcpp::init(0, nullptr);
    }
#endif
    ConsoleOptions opts;
    opts.enable = true;
    opts.level = LogLevel::DEBUG;
    Initialize(opts);
  }
};

TEST_F(XlogIntegrationTest, WouldAcceptConsoleAtDebugLevel) {
  auto& ctrl = LogControler::GetInstance();
  EXPECT_TRUE(ctrl.WouldAcceptConsole(LogLevel::DEBUG));
  EXPECT_TRUE(ctrl.WouldAcceptConsole(LogLevel::INFO));
  EXPECT_TRUE(ctrl.WouldAcceptConsole(LogLevel::WARNING));
  EXPECT_TRUE(ctrl.WouldAcceptConsole(LogLevel::FATAL));
}

TEST_F(XlogIntegrationTest, SetLevelFiltersCorrectly) {
  auto& ctrl = LogControler::GetInstance();
  SetConsoleLevel(LogLevel::INFO);

  EXPECT_FALSE(ctrl.WouldAcceptConsole(LogLevel::DEBUG));
  EXPECT_TRUE(ctrl.WouldAcceptConsole(LogLevel::INFO));
  EXPECT_TRUE(ctrl.WouldAcceptConsole(LogLevel::WARNING));
  EXPECT_TRUE(ctrl.WouldAcceptConsole(LogLevel::FATAL));

  SetConsoleLevel(LogLevel::WARNING);
  EXPECT_FALSE(ctrl.WouldAcceptConsole(LogLevel::DEBUG));
  EXPECT_FALSE(ctrl.WouldAcceptConsole(LogLevel::INFO));
  EXPECT_TRUE(ctrl.WouldAcceptConsole(LogLevel::WARNING));
  EXPECT_TRUE(ctrl.WouldAcceptConsole(LogLevel::FATAL));

  SetConsoleLevel(LogLevel::DEBUG);
}

}  // namespace log
}  // namespace xos
