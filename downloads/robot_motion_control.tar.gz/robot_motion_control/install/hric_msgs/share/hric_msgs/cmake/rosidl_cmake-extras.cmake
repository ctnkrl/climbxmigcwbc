# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(hric_msgs_IDL_FILES "msg/FootPoint.idl")
set(hric_msgs_INTERFACE_FILES "msg/FootPoint.msg")
