// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from hric_msgs:msg/FootPoint.idl
// generated code does not contain a copyright notice
#ifndef HRIC_MSGS__MSG__DETAIL__FOOT_POINT__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define HRIC_MSGS__MSG__DETAIL__FOOT_POINT__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "hric_msgs/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"
#include "hric_msgs/msg/detail/foot_point__struct.h"
#include "fastcdr/Cdr.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_hric_msgs
bool cdr_serialize_hric_msgs__msg__FootPoint(
  const hric_msgs__msg__FootPoint * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_hric_msgs
bool cdr_deserialize_hric_msgs__msg__FootPoint(
  eprosima::fastcdr::Cdr &,
  hric_msgs__msg__FootPoint * ros_message);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_hric_msgs
size_t get_serialized_size_hric_msgs__msg__FootPoint(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_hric_msgs
size_t max_serialized_size_hric_msgs__msg__FootPoint(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_hric_msgs
bool cdr_serialize_key_hric_msgs__msg__FootPoint(
  const hric_msgs__msg__FootPoint * ros_message,
  eprosima::fastcdr::Cdr & cdr);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_hric_msgs
size_t get_serialized_size_key_hric_msgs__msg__FootPoint(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_hric_msgs
size_t max_serialized_size_key_hric_msgs__msg__FootPoint(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_hric_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, hric_msgs, msg, FootPoint)();

#ifdef __cplusplus
}
#endif

#endif  // HRIC_MSGS__MSG__DETAIL__FOOT_POINT__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
