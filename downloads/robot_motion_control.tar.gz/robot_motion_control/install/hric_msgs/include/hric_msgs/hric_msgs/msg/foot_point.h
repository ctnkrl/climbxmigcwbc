// generated from rosidl_generator_c/resource/idl.h.em
// with input from hric_msgs:msg/FootPoint.idl
// generated code does not contain a copyright notice

#ifndef HRIC_MSGS__MSG__FOOT_POINT_H_
#define HRIC_MSGS__MSG__FOOT_POINT_H_

#include "hric_msgs/msg/detail/foot_point__struct.h"
#include "hric_msgs/msg/detail/foot_point__functions.h"
#include "hric_msgs/msg/detail/foot_point__type_support.h"

#endif  // HRIC_MSGS__MSG__FOOT_POINT_H_
