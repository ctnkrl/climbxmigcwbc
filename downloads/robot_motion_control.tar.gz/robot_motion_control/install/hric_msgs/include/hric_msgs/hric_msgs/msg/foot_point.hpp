// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef HRIC_MSGS__MSG__FOOT_POINT_HPP_
#define HRIC_MSGS__MSG__FOOT_POINT_HPP_

#include "hric_msgs/msg/detail/foot_point__struct.hpp"
#include "hric_msgs/msg/detail/foot_point__builder.hpp"
#include "hric_msgs/msg/detail/foot_point__traits.hpp"
#include "hric_msgs/msg/detail/foot_point__type_support.hpp"

#endif  // HRIC_MSGS__MSG__FOOT_POINT_HPP_
