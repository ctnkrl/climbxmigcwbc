﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from hric_msgs:msg/FootPoint.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "hric_msgs/msg/foot_point.h"


#ifndef HRIC_MSGS__MSG__DETAIL__FOOT_POINT__STRUCT_H_
#define HRIC_MSGS__MSG__DETAIL__FOOT_POINT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'frame_id'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/FootPoint in the package hric_msgs.
/**
  * 落脚点信息消息
  * 用于发布机器人距离目标点1米左右时的落脚点信息
 */
typedef struct hric_msgs__msg__FootPoint
{
  /// 时间戳
  builtin_interfaces__msg__Time stamp;
  /// 开关标志：距离目标点小于1米时为true，否则为false
  bool footflag;
  /// 相对坐标信息（机器人坐标系下）
  /// x坐标：机器人到目标点的相对x坐标
  double relative_x;
  /// y坐标：机器人到目标点的相对y坐标
  double relative_y;
  /// 相对航向角：机器人到目标点的相对航向角（弧度）
  double relative_yaw;
  /// 距离信息
  /// 机器人与目标点的直线距离
  double distance;
  /// 坐标系信息
  rosidl_runtime_c__String frame_id;
} hric_msgs__msg__FootPoint;

// Struct for a sequence of hric_msgs__msg__FootPoint.
typedef struct hric_msgs__msg__FootPoint__Sequence
{
  hric_msgs__msg__FootPoint * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} hric_msgs__msg__FootPoint__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // HRIC_MSGS__MSG__DETAIL__FOOT_POINT__STRUCT_H_
