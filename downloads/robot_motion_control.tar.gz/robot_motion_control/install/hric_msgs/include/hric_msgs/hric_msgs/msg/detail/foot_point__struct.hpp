// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from hric_msgs:msg/FootPoint.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "hric_msgs/msg/foot_point.hpp"


#ifndef HRIC_MSGS__MSG__DETAIL__FOOT_POINT__STRUCT_HPP_
#define HRIC_MSGS__MSG__DETAIL__FOOT_POINT__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__hric_msgs__msg__FootPoint __attribute__((deprecated))
#else
# define DEPRECATED__hric_msgs__msg__FootPoint __declspec(deprecated)
#endif

namespace hric_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct FootPoint_
{
  using Type = FootPoint_<ContainerAllocator>;

  explicit FootPoint_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : stamp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->footflag = false;
      this->relative_x = 0.0;
      this->relative_y = 0.0;
      this->relative_yaw = 0.0;
      this->distance = 0.0;
      this->frame_id = "";
    }
  }

  explicit FootPoint_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : stamp(_alloc, _init),
    frame_id(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->footflag = false;
      this->relative_x = 0.0;
      this->relative_y = 0.0;
      this->relative_yaw = 0.0;
      this->distance = 0.0;
      this->frame_id = "";
    }
  }

  // field types and members
  using _stamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _stamp_type stamp;
  using _footflag_type =
    bool;
  _footflag_type footflag;
  using _relative_x_type =
    double;
  _relative_x_type relative_x;
  using _relative_y_type =
    double;
  _relative_y_type relative_y;
  using _relative_yaw_type =
    double;
  _relative_yaw_type relative_yaw;
  using _distance_type =
    double;
  _distance_type distance;
  using _frame_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _frame_id_type frame_id;

  // setters for named parameter idiom
  Type & set__stamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->stamp = _arg;
    return *this;
  }
  Type & set__footflag(
    const bool & _arg)
  {
    this->footflag = _arg;
    return *this;
  }
  Type & set__relative_x(
    const double & _arg)
  {
    this->relative_x = _arg;
    return *this;
  }
  Type & set__relative_y(
    const double & _arg)
  {
    this->relative_y = _arg;
    return *this;
  }
  Type & set__relative_yaw(
    const double & _arg)
  {
    this->relative_yaw = _arg;
    return *this;
  }
  Type & set__distance(
    const double & _arg)
  {
    this->distance = _arg;
    return *this;
  }
  Type & set__frame_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->frame_id = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    hric_msgs::msg::FootPoint_<ContainerAllocator> *;
  using ConstRawPtr =
    const hric_msgs::msg::FootPoint_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<hric_msgs::msg::FootPoint_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<hric_msgs::msg::FootPoint_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      hric_msgs::msg::FootPoint_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<hric_msgs::msg::FootPoint_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      hric_msgs::msg::FootPoint_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<hric_msgs::msg::FootPoint_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<hric_msgs::msg::FootPoint_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<hric_msgs::msg::FootPoint_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__hric_msgs__msg__FootPoint
    std::shared_ptr<hric_msgs::msg::FootPoint_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__hric_msgs__msg__FootPoint
    std::shared_ptr<hric_msgs::msg::FootPoint_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const FootPoint_ & other) const
  {
    if (this->stamp != other.stamp) {
      return false;
    }
    if (this->footflag != other.footflag) {
      return false;
    }
    if (this->relative_x != other.relative_x) {
      return false;
    }
    if (this->relative_y != other.relative_y) {
      return false;
    }
    if (this->relative_yaw != other.relative_yaw) {
      return false;
    }
    if (this->distance != other.distance) {
      return false;
    }
    if (this->frame_id != other.frame_id) {
      return false;
    }
    return true;
  }
  bool operator!=(const FootPoint_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct FootPoint_

// alias to use template instance with default allocator
using FootPoint =
  hric_msgs::msg::FootPoint_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace hric_msgs

#endif  // HRIC_MSGS__MSG__DETAIL__FOOT_POINT__STRUCT_HPP_
