// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from hric_msgs:msg/FootPoint.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "hric_msgs/msg/foot_point.h"


#ifndef HRIC_MSGS__MSG__DETAIL__FOOT_POINT__TYPE_SUPPORT_H_
#define HRIC_MSGS__MSG__DETAIL__FOOT_POINT__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "hric_msgs/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_hric_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  hric_msgs,
  msg,
  FootPoint
)(void);

#ifdef __cplusplus
}
#endif

#endif  // HRIC_MSGS__MSG__DETAIL__FOOT_POINT__TYPE_SUPPORT_H_
