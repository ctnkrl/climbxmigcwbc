// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from hric_msgs:msg/FootPoint.idl
// generated code does not contain a copyright notice

#include "hric_msgs/msg/detail/foot_point__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_hric_msgs
const rosidl_type_hash_t *
hric_msgs__msg__FootPoint__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0xdf, 0x12, 0x63, 0xbc, 0xf1, 0x10, 0x2e, 0x97,
      0xbb, 0xb9, 0x64, 0xa6, 0x7b, 0x24, 0x52, 0x8e,
      0x38, 0xf7, 0x1f, 0xcd, 0x53, 0xeb, 0xab, 0xe9,
      0x51, 0x08, 0x01, 0xcc, 0x87, 0x38, 0x3a, 0xd2,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types
#include "builtin_interfaces/msg/detail/time__functions.h"

// Hashes for external referenced types
#ifndef NDEBUG
static const rosidl_type_hash_t builtin_interfaces__msg__Time__EXPECTED_HASH = {1, {
    0xb1, 0x06, 0x23, 0x5e, 0x25, 0xa4, 0xc5, 0xed,
    0x35, 0x09, 0x8a, 0xa0, 0xa6, 0x1a, 0x3e, 0xe9,
    0xc9, 0xb1, 0x8d, 0x19, 0x7f, 0x39, 0x8b, 0x0e,
    0x42, 0x06, 0xce, 0xa9, 0xac, 0xf9, 0xc1, 0x97,
  }};
#endif

static char hric_msgs__msg__FootPoint__TYPE_NAME[] = "hric_msgs/msg/FootPoint";
static char builtin_interfaces__msg__Time__TYPE_NAME[] = "builtin_interfaces/msg/Time";

// Define type names, field names, and default values
static char hric_msgs__msg__FootPoint__FIELD_NAME__stamp[] = "stamp";
static char hric_msgs__msg__FootPoint__FIELD_NAME__footflag[] = "footflag";
static char hric_msgs__msg__FootPoint__FIELD_NAME__relative_x[] = "relative_x";
static char hric_msgs__msg__FootPoint__FIELD_NAME__relative_y[] = "relative_y";
static char hric_msgs__msg__FootPoint__FIELD_NAME__relative_yaw[] = "relative_yaw";
static char hric_msgs__msg__FootPoint__FIELD_NAME__distance[] = "distance";
static char hric_msgs__msg__FootPoint__FIELD_NAME__frame_id[] = "frame_id";

static rosidl_runtime_c__type_description__Field hric_msgs__msg__FootPoint__FIELDS[] = {
  {
    {hric_msgs__msg__FootPoint__FIELD_NAME__stamp, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_NESTED_TYPE,
      0,
      0,
      {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    },
    {NULL, 0, 0},
  },
  {
    {hric_msgs__msg__FootPoint__FIELD_NAME__footflag, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_BOOLEAN,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {hric_msgs__msg__FootPoint__FIELD_NAME__relative_x, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {hric_msgs__msg__FootPoint__FIELD_NAME__relative_y, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {hric_msgs__msg__FootPoint__FIELD_NAME__relative_yaw, 12, 12},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {hric_msgs__msg__FootPoint__FIELD_NAME__distance, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_DOUBLE,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {hric_msgs__msg__FootPoint__FIELD_NAME__frame_id, 8, 8},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

static rosidl_runtime_c__type_description__IndividualTypeDescription hric_msgs__msg__FootPoint__REFERENCED_TYPE_DESCRIPTIONS[] = {
  {
    {builtin_interfaces__msg__Time__TYPE_NAME, 27, 27},
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
hric_msgs__msg__FootPoint__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {hric_msgs__msg__FootPoint__TYPE_NAME, 23, 23},
      {hric_msgs__msg__FootPoint__FIELDS, 7, 7},
    },
    {hric_msgs__msg__FootPoint__REFERENCED_TYPE_DESCRIPTIONS, 1, 1},
  };
  if (!constructed) {
    assert(0 == memcmp(&builtin_interfaces__msg__Time__EXPECTED_HASH, builtin_interfaces__msg__Time__get_type_hash(NULL), sizeof(rosidl_type_hash_t)));
    description.referenced_type_descriptions.data[0].fields = builtin_interfaces__msg__Time__get_type_description(NULL)->type_description.fields;
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "# \\xe8\\x90\\xbd\\xe8\\x84\\x9a\\xe7\\x82\\xb9\\xe4\\xbf\\xa1\\xe6\\x81\\xaf\\xe6\\xb6\\x88\\xe6\\x81\\xaf\n"
  "# \\xe7\\x94\\xa8\\xe4\\xba\\x8e\\xe5\\x8f\\x91\\xe5\\xb8\\x83\\xe6\\x9c\\xba\\xe5\\x99\\xa8\\xe4\\xba\\xba\\xe8\\xb7\\x9d\\xe7\\xa6\\xbb\\xe7\\x9b\\xae\\xe6\\xa0\\x87\\xe7\\x82\\xb91\\xe7\\xb1\\xb3\\xe5\\xb7\\xa6\\xe5\\x8f\\xb3\\xe6\\x97\\xb6\\xe7\\x9a\\x84\\xe8\\x90\\xbd\\xe8\\x84\\x9a\\xe7\\x82\\xb9\\xe4\\xbf\\xa1\\xe6\\x81\\xaf\n"
  "\n"
  "# \\xe6\\x97\\xb6\\xe9\\x97\\xb4\\xe6\\x88\\xb3\n"
  "builtin_interfaces/Time stamp\n"
  "\n"
  "# \\xe5\\xbc\\x80\\xe5\\x85\\xb3\\xe6\\xa0\\x87\\xe5\\xbf\\x97\\xef\\xbc\\x9a\\xe8\\xb7\\x9d\\xe7\\xa6\\xbb\\xe7\\x9b\\xae\\xe6\\xa0\\x87\\xe7\\x82\\xb9\\xe5\\xb0\\x8f\\xe4\\xba\\x8e1\\xe7\\xb1\\xb3\\xe6\\x97\\xb6\\xe4\\xb8\\xbatrue\\xef\\xbc\\x8c\\xe5\\x90\\xa6\\xe5\\x88\\x99\\xe4\\xb8\\xbafalse\n"
  "bool footflag\n"
  "\n"
  "# \\xe7\\x9b\\xb8\\xe5\\xaf\\xb9\\xe5\\x9d\\x90\\xe6\\xa0\\x87\\xe4\\xbf\\xa1\\xe6\\x81\\xaf\\xef\\xbc\\x88\\xe6\\x9c\\xba\\xe5\\x99\\xa8\\xe4\\xba\\xba\\xe5\\x9d\\x90\\xe6\\xa0\\x87\\xe7\\xb3\\xbb\\xe4\\xb8\\x8b\\xef\\xbc\\x89\n"
  "# x\\xe5\\x9d\\x90\\xe6\\xa0\\x87\\xef\\xbc\\x9a\\xe6\\x9c\\xba\\xe5\\x99\\xa8\\xe4\\xba\\xba\\xe5\\x88\\xb0\\xe7\\x9b\\xae\\xe6\\xa0\\x87\\xe7\\x82\\xb9\\xe7\\x9a\\x84\\xe7\\x9b\\xb8\\xe5\\xaf\\xb9x\\xe5\\x9d\\x90\\xe6\\xa0\\x87\n"
  "float64 relative_x\n"
  "# y\\xe5\\x9d\\x90\\xe6\\xa0\\x87\\xef\\xbc\\x9a\\xe6\\x9c\\xba\\xe5\\x99\\xa8\\xe4\\xba\\xba\\xe5\\x88\\xb0\\xe7\\x9b\\xae\\xe6\\xa0\\x87\\xe7\\x82\\xb9\\xe7\\x9a\\x84\\xe7\\x9b\\xb8\\xe5\\xaf\\xb9y\\xe5\\x9d\\x90\\xe6\\xa0\\x87  \n"
  "float64 relative_y\n"
  "# \\xe7\\x9b\\xb8\\xe5\\xaf\\xb9\\xe8\\x88\\xaa\\xe5\\x90\\x91\\xe8\\xa7\\x92\\xef\\xbc\\x9a\\xe6\\x9c\\xba\\xe5\\x99\\xa8\\xe4\\xba\\xba\\xe5\\x88\\xb0\\xe7\\x9b\\xae\\xe6\\xa0\\x87\\xe7\\x82\\xb9\\xe7\\x9a\\x84\\xe7\\x9b\\xb8\\xe5\\xaf\\xb9\\xe8\\x88\\xaa\\xe5\\x90\\x91\\xe8\\xa7\\x92\\xef\\xbc\\x88\\xe5\\xbc\\xa7\\xe5\\xba\\xa6\\xef\\xbc\\x89\n"
  "float64 relative_yaw\n"
  "\n"
  "# \\xe8\\xb7\\x9d\\xe7\\xa6\\xbb\\xe4\\xbf\\xa1\\xe6\\x81\\xaf\n"
  "# \\xe6\\x9c\\xba\\xe5\\x99\\xa8\\xe4\\xba\\xba\\xe4\\xb8\\x8e\\xe7\\x9b\\xae\\xe6\\xa0\\x87\\xe7\\x82\\xb9\\xe7\\x9a\\x84\\xe7\\x9b\\xb4\\xe7\\xba\\xbf\\xe8\\xb7\\x9d\\xe7\\xa6\\xbb\n"
  "float64 distance\n"
  "\n"
  "# \\xe5\\x9d\\x90\\xe6\\xa0\\x87\\xe7\\xb3\\xbb\\xe4\\xbf\\xa1\\xe6\\x81\\xaf\n"
  "string frame_id";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
hric_msgs__msg__FootPoint__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {hric_msgs__msg__FootPoint__TYPE_NAME, 23, 23},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 330, 330},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
hric_msgs__msg__FootPoint__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[2];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 2, 2};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *hric_msgs__msg__FootPoint__get_individual_type_description_source(NULL),
    sources[1] = *builtin_interfaces__msg__Time__get_individual_type_description_source(NULL);
    constructed = true;
  }
  return &source_sequence;
}
