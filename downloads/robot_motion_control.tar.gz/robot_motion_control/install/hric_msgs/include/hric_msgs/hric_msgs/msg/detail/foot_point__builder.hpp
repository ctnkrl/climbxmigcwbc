// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from hric_msgs:msg/FootPoint.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "hric_msgs/msg/foot_point.hpp"


#ifndef HRIC_MSGS__MSG__DETAIL__FOOT_POINT__BUILDER_HPP_
#define HRIC_MSGS__MSG__DETAIL__FOOT_POINT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "hric_msgs/msg/detail/foot_point__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace hric_msgs
{

namespace msg
{

namespace builder
{

class Init_FootPoint_frame_id
{
public:
  explicit Init_FootPoint_frame_id(::hric_msgs::msg::FootPoint & msg)
  : msg_(msg)
  {}
  ::hric_msgs::msg::FootPoint frame_id(::hric_msgs::msg::FootPoint::_frame_id_type arg)
  {
    msg_.frame_id = std::move(arg);
    return std::move(msg_);
  }

private:
  ::hric_msgs::msg::FootPoint msg_;
};

class Init_FootPoint_distance
{
public:
  explicit Init_FootPoint_distance(::hric_msgs::msg::FootPoint & msg)
  : msg_(msg)
  {}
  Init_FootPoint_frame_id distance(::hric_msgs::msg::FootPoint::_distance_type arg)
  {
    msg_.distance = std::move(arg);
    return Init_FootPoint_frame_id(msg_);
  }

private:
  ::hric_msgs::msg::FootPoint msg_;
};

class Init_FootPoint_relative_yaw
{
public:
  explicit Init_FootPoint_relative_yaw(::hric_msgs::msg::FootPoint & msg)
  : msg_(msg)
  {}
  Init_FootPoint_distance relative_yaw(::hric_msgs::msg::FootPoint::_relative_yaw_type arg)
  {
    msg_.relative_yaw = std::move(arg);
    return Init_FootPoint_distance(msg_);
  }

private:
  ::hric_msgs::msg::FootPoint msg_;
};

class Init_FootPoint_relative_y
{
public:
  explicit Init_FootPoint_relative_y(::hric_msgs::msg::FootPoint & msg)
  : msg_(msg)
  {}
  Init_FootPoint_relative_yaw relative_y(::hric_msgs::msg::FootPoint::_relative_y_type arg)
  {
    msg_.relative_y = std::move(arg);
    return Init_FootPoint_relative_yaw(msg_);
  }

private:
  ::hric_msgs::msg::FootPoint msg_;
};

class Init_FootPoint_relative_x
{
public:
  explicit Init_FootPoint_relative_x(::hric_msgs::msg::FootPoint & msg)
  : msg_(msg)
  {}
  Init_FootPoint_relative_y relative_x(::hric_msgs::msg::FootPoint::_relative_x_type arg)
  {
    msg_.relative_x = std::move(arg);
    return Init_FootPoint_relative_y(msg_);
  }

private:
  ::hric_msgs::msg::FootPoint msg_;
};

class Init_FootPoint_footflag
{
public:
  explicit Init_FootPoint_footflag(::hric_msgs::msg::FootPoint & msg)
  : msg_(msg)
  {}
  Init_FootPoint_relative_x footflag(::hric_msgs::msg::FootPoint::_footflag_type arg)
  {
    msg_.footflag = std::move(arg);
    return Init_FootPoint_relative_x(msg_);
  }

private:
  ::hric_msgs::msg::FootPoint msg_;
};

class Init_FootPoint_stamp
{
public:
  Init_FootPoint_stamp()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_FootPoint_footflag stamp(::hric_msgs::msg::FootPoint::_stamp_type arg)
  {
    msg_.stamp = std::move(arg);
    return Init_FootPoint_footflag(msg_);
  }

private:
  ::hric_msgs::msg::FootPoint msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::hric_msgs::msg::FootPoint>()
{
  return hric_msgs::msg::builder::Init_FootPoint_stamp();
}

}  // namespace hric_msgs

#endif  // HRIC_MSGS__MSG__DETAIL__FOOT_POINT__BUILDER_HPP_
