// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from hric_msgs:msg/FootPoint.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "hric_msgs/msg/foot_point.hpp"


#ifndef HRIC_MSGS__MSG__DETAIL__FOOT_POINT__TRAITS_HPP_
#define HRIC_MSGS__MSG__DETAIL__FOOT_POINT__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "hric_msgs/msg/detail/foot_point__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace hric_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const FootPoint & msg,
  std::ostream & out)
{
  out << "{";
  // member: stamp
  {
    out << "stamp: ";
    to_flow_style_yaml(msg.stamp, out);
    out << ", ";
  }

  // member: footflag
  {
    out << "footflag: ";
    rosidl_generator_traits::value_to_yaml(msg.footflag, out);
    out << ", ";
  }

  // member: relative_x
  {
    out << "relative_x: ";
    rosidl_generator_traits::value_to_yaml(msg.relative_x, out);
    out << ", ";
  }

  // member: relative_y
  {
    out << "relative_y: ";
    rosidl_generator_traits::value_to_yaml(msg.relative_y, out);
    out << ", ";
  }

  // member: relative_yaw
  {
    out << "relative_yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.relative_yaw, out);
    out << ", ";
  }

  // member: distance
  {
    out << "distance: ";
    rosidl_generator_traits::value_to_yaml(msg.distance, out);
    out << ", ";
  }

  // member: frame_id
  {
    out << "frame_id: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_id, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const FootPoint & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: stamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "stamp:\n";
    to_block_style_yaml(msg.stamp, out, indentation + 2);
  }

  // member: footflag
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "footflag: ";
    rosidl_generator_traits::value_to_yaml(msg.footflag, out);
    out << "\n";
  }

  // member: relative_x
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "relative_x: ";
    rosidl_generator_traits::value_to_yaml(msg.relative_x, out);
    out << "\n";
  }

  // member: relative_y
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "relative_y: ";
    rosidl_generator_traits::value_to_yaml(msg.relative_y, out);
    out << "\n";
  }

  // member: relative_yaw
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "relative_yaw: ";
    rosidl_generator_traits::value_to_yaml(msg.relative_yaw, out);
    out << "\n";
  }

  // member: distance
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "distance: ";
    rosidl_generator_traits::value_to_yaml(msg.distance, out);
    out << "\n";
  }

  // member: frame_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "frame_id: ";
    rosidl_generator_traits::value_to_yaml(msg.frame_id, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const FootPoint & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace hric_msgs

namespace rosidl_generator_traits
{

[[deprecated("use hric_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const hric_msgs::msg::FootPoint & msg,
  std::ostream & out, size_t indentation = 0)
{
  hric_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use hric_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const hric_msgs::msg::FootPoint & msg)
{
  return hric_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<hric_msgs::msg::FootPoint>()
{
  return "hric_msgs::msg::FootPoint";
}

template<>
inline const char * name<hric_msgs::msg::FootPoint>()
{
  return "hric_msgs/msg/FootPoint";
}

template<>
struct has_fixed_size<hric_msgs::msg::FootPoint>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<hric_msgs::msg::FootPoint>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<hric_msgs::msg::FootPoint>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // HRIC_MSGS__MSG__DETAIL__FOOT_POINT__TRAITS_HPP_
